package com.openwebinars.demo.beans;

import java.util.List;

public interface Query {
    List<String> fetchData();
}
