package com.InicioUsuario.repaso.Persistance.Enum;

public enum Role {
    ADMIN,
    USER;
}
