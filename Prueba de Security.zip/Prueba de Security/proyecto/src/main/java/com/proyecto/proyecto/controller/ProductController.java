package com.proyecto.proyecto.controller;

public class ProductController {
}
