package com.proyecto01.proyecto01.service;

import com.proyecto01.proyecto01.models.Product;

import java.util.List;

public interface ProductService {

    List<Product> getProducts();

}
