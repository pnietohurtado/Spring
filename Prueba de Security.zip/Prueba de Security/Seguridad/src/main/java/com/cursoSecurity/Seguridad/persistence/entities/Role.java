package com.cursoSecurity.Seguridad.persistence.entities;

public enum Role {
    ADMIN,
    USER,
    DEVELOPER;
}
