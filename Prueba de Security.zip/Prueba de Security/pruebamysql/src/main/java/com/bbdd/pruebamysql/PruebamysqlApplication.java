package com.bbdd.pruebamysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebamysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebamysqlApplication.class, args);
	}

}
