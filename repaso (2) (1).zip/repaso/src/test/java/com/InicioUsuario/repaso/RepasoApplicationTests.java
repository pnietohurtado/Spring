package com.InicioUsuario.repaso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepasoApplicationTests {

	@Test
	void contextLoads() {
	}

}
