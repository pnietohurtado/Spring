package com.websockets.webSockets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSocketsApplicationTests {

	@Test
	void contextLoads() {
	}

}
