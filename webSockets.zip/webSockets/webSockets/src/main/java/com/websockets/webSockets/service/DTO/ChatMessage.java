package com.websockets.webSockets.service.DTO;

public record ChatMessage(String content, String sender) {
}
