insert into productos(id,nombre,precio) values (NEXTVAL(1), "Otro producto", 23.45);
insert into productos(id,nombre,precio) values (NEXTVAL(2), "Monitor", 2333.45);
insert into productos(id,nombre,precio) values (NEXTVAL(3), "Impresora", 1.45);
insert into productos(id,nombre,precio) values (NEXTVAL(4), "Ratón", 67.45);
insert into productos(id,nombre,precio) values (NEXTVAL(5), "Teclado", 99.45);