package com.proyecto.proyecto;

import org.springframework.stereotype.Component;

@Component
public class Alien {

    public void code(){
        System.out.println("Start coding");
    }
}
