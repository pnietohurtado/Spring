insert into student(rollno, name, marks) values (104, 'Pablo', 100);
insert into student(rollno, name, marks) values (102, 'Pepe', 23);
insert into student(rollno, name, marks) values (103, 'Juan', 70);