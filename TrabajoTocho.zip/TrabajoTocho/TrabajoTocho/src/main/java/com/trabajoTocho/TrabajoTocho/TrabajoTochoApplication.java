package com.trabajoTocho.TrabajoTocho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoTochoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoTochoApplication.class, args);
	}

}
