package com.openwebinars.web;

import jakarta.servlet.annotation.WebServlet;

@WebServlet("/hola-mundo")
public class HolaMundoServlet {



}
