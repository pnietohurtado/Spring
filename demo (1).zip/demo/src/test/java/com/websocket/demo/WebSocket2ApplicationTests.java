package com.websocket.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSocket2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
