package com.proyecto.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class ProyectoApplication {

	public static void main(String[] args) {
		ApplicationContext content = SpringApplication.run(ProyectoApplication.class, args);
		Alien al = content.getBean(Alien.class);
		al.code();
	}

}
