INSERT INTO user(id,firstName, lastName, email) VALUES (1, 'Pablo', 'Nieto', 'pnh0002@alu.medac.es');
INSERT INTO user(id,firstName, lastName, email) VALUES (2, 'Pepe', 'Ortega', 'pnh0002@alu.medac.es');
INSERT INTO user(id,firstName, lastName, email) VALUES (3, 'Juan', 'Hurtado', 'pnh0002@alu.medac.es');
INSERT INTO user(id,firstName, lastName, email) VALUES (4, 'Angel', 'Gasol', 'pnh0002@alu.medac.es');