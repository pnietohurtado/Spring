package com.openwebinars.demo.anotaciones;

import org.springframework.stereotype.Component;

@Component // Esto es lo que la hace un Bean
public class miprimerBean {

    public miprimerBean(){

    }


}
