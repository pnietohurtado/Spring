package com.openwebinars.demo.autowired;


import java.util.List;

public interface DataReader {
    List<String> readData();

}
