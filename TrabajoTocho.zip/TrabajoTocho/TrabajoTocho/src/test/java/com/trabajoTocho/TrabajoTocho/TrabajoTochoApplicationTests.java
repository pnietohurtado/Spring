package com.trabajoTocho.TrabajoTocho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoTochoApplicationTests {

	@Test
	void contextLoads() {
	}

}
