package com.pruebaChat.PruebaChat.controller;

public record Message(
        String body
) {
}
