package com.cursoSecurity.Seguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
