package com.jdbc.JavaDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
