package com.pruebaChat.PruebaChat.controller;

public record Information(
        String content
) {
}
