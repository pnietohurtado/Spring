package com.bbdd.pruebamysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebamysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
