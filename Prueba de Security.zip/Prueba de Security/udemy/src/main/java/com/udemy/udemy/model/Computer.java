package com.udemy.udemy.model;

public interface Computer {
    void compile();
}
