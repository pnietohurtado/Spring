package com.openwebinars.demo.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class ConfigQuery {
    /*
    @Primary
    @Bean
    public DBQuery dbQuery() {
        return new DBQuery();
    }

    @Bean
    public FileQuery fileQuery(){
        return new FileQuery();
    }
    */

}
