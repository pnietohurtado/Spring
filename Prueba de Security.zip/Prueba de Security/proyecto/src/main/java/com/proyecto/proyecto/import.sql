insert into product (id, nombre, categoria, precio, imagen) values (NEXTVAL('product_seq'), 'Camiseta', 'Ropa', 15.99, 'http')
insert into product (id, nombre, categoria, precio, imagen) values (NEXTVAL('product_seq'), 'Pantalon', 'Ropa', 15.99, 'http')
insert into product (id, nombre, categoria, precio, imagen) values (NEXTVAL('product_seq'), 'Pijama', 'Ropa', 15.99, 'http')
insert into product (id, nombre, categoria, precio, imagen) values (NEXTVAL('product_seq'), 'Zapatos', 'Ropa', 15.99, 'http')