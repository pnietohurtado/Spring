package com.proyecto01.proyecto01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Proyecto01Application {

	public static void main(String[] args) {
		ApplicationContext c = SpringApplication.run(Proyecto01Application.class, args);
	}

}
