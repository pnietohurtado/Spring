package com.trabajoTocho.TrabajoTocho;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.lang.module.Configuration;

@SpringBootApplication
public class TrabajoTochoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoTochoApplication.class, args);

	}

}
