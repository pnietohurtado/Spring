package com.pruebaChat.PruebaChat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
