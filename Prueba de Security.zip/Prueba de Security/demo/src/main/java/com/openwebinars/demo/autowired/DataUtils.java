package com.openwebinars.demo.autowired;

import org.springframework.stereotype.Component;

@Component
public class DataUtils {
}
